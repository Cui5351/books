const express=require('express')
const cors=require('cors')
const {readFile, readFileSync}=require('fs')
const {query} =require('./query')
const {connectionMysql,insertData, update}=require('./dbs')
const { resolve } = require('path')
const https=require('https')
const { default: axios } = require('axios')
// 创建app
const app=express()

// 解析post请求数据
app.use(express.urlencoded({ extended: true }))
app.use(express.json())


app.use(cors())
const options = {
  key: readFileSync(resolve(__dirname, 'cert','a.key')),
  cert: readFileSync(resolve(__dirname, 'cert','a.pem'))
}
entry()

function entry(){
    // 解析文件
    readFile('./base_config.json',async function(err,data){   
        if(err) return 
        data=JSON.parse(data.toString())
        const {server_config,db_config}=data

// 这是机制问题，当没有操作数据的时候，就断开连接了 在网站stackoverflow看到了解决方案 强制连接,让数据库每1hours查询一次        
        
        await connectionMysql(db_config).then(value=>{
            MountRouter(server_config.port,value,db_config)  
            https.createServer(options,app).listen('5000',function(){
            })  
        })
    })
}


// 路由注入
function MountRouter(port,dbs,db_config){
        app.get('/',(req,res)=>{
            res.send({
                value:'hello'
            })
        })

        app.post('/small_program_state',function(req,res){
            if(typeof req.body === 'string')
                req.body=JSON.parse(req.body)
            if(!req.body.hasOwnProperty('small_program_name')){
                res.send({
                    state:0,
                    errorCode:1,
                    errorMes:'缺少参数'
                })
                return 
            }
            
            for(let item in req.body){
                if(typeof req.body[item] === 'string')
                    if(req.body[item].trim().length<1){
                        res.send({
                            state:0,
                            errorCode:2,
                            errorMes:"数据值无效(上传数据为空|长度小于1)"
                        })
                        return
                }            
            }   
            const {small_program_name}=req.body
            query(dbs,db_config.database+'.small_program_state',['state'],{small_program_name:small_program_name}).then(value=>{
                // 为1
                if(Number(value[0].state)){
                    res.send({
                        state:1,
                        error:0,
                        value:Number(value[0].state)
                    })
                    return
                }
                // 为0
                res.send({
                    state:1,
                    error:0,
                    value:0
                })
            })
    })

    app.post('/getBookInfo',function(req,res){
        query(dbs,db_config.database+'.books_info',['book_name','author','book_introduce']).then(value=>{
            res.send({
                state:1,
                error:0,
                data:value
            })
            return
        })
    })
    app.post('/send_answer',function(req,res){
        // 参数列表->
            // my_openid:<string>
            // send_object_openid:<string>
            // message:<string>        
         if(typeof req.body === 'string')
                req.body=JSON.parse(req.body)
            if(!req.body.hasOwnProperty('my_openid')||!req.body.hasOwnProperty('message')||!req.body.hasOwnProperty('send_object_openid')){
                res.send({
                    state:0,
                    errorCode:1,
                    errorMes:'缺少参数'
                })
                return 
            }
            
            for(let item in req.body){
                if(typeof req.body[item] === 'string')
                    if(req.body[item].trim().length<1){
                        res.send({
                            state:0,
                            errorCode:2,
                            errorMes:"数据值无效(上传数据为空|长度小于1)"
                        })
                        return
                }
            }   
        const {my_openid,send_object_openid,message}=req.body

        // 先拿到my_openid的权限user_privilege
        // 没拿到就返回无权限
        query(dbs,db_config.database+'.user_info','user_privilege',{openid:my_openid}).then(e=>{
            if(e.length<=0){
                res.send({
                    state:0,
                    error:1,
                    errorMes:'用户状态异常,请在小程序上重新登录'
                })
                return
            }
            if(e[0].user_privilege=='normal'){
                res.send({
                    state:0,
                    error:1,
                    errorMes:'用户无权限'
                })
                return
            }
            // 拿到所有回复
        query(dbs,db_config.database+'.user_info',e[0].user_privilege=='author'?'author_answer':'data_provide_answer',{openid:send_object_openid}).then(e2=>{
            if(e2.length<=0){
                res.send({
                    state:0,
                    error:1,
                    errorMes:'用户状态异常,请在小程序上重新登录'
                })
                return
            }
            let answers=JSON.parse(e2[0][e[0].user_privilege=='author'?'author_answer':'data_provide_answer'])
            answers.push(message)
            answers=JSON.stringify(answers)
            // 然后给回复里添加内容
            update(dbs,db_config.database+'.user_info',{openid:send_object_openid},e[0].user_privilege=='author'?'author_answer':'data_provide_answer',answers,'string').then(e=>{
                res.send({
                    state:1,
                    error:0,
                })
                return
            }).catch(e=>{
                res.send({
                    state:0,
                    error:1,
                    errorMes:e
                })
                return                
            })

        })

        })


    })
        app.post('/login',function(req,res){
            if(typeof req.body === 'string')
                req.body=JSON.parse(req.body)
            if(!req.body.hasOwnProperty('name')||!req.body.hasOwnProperty('password')){
                res.send({
                    state:0,
                    errorCode:1,
                    errorMes:'缺少参数'
                })
                return 
            }
            
            for(let item in req.body){
                if(typeof req.body[item] === 'string')
                    if(req.body[item].trim().length<1){
                        res.send({
                            state:0,
                            errorCode:2,
                            errorMes:"数据值无效(上传数据为空|长度小于1)"
                        })
                        return
                }
            }   

            // state：返回含义
                // 0：密码错误
                // 1：可以登录（密码正确）
                // 2：不包含（需在小程序上登录）

            // errorCode：返回韩意思
                // 0：无错误信息
                // 1：密码错误
            const {name,password}=req.body
            // 查询并返回
            query(dbs,'mynameisczy_asia.user_info','',{openid:password}).then(v=>{
                // 存在
                if(v.length){
                    // 查询密码是否正确
                query(dbs,'mynameisczy_asia.user_info','',{nickName:name,openid:password}).then(v=>{
                    if(v.length){
                        // 正确correct
                        res.send({ 
                            state:1,
                            errorCode:0,
                            data:v[0]
                        })
                    }else{
                        // 不正确incorrect
                        res.send({
                            state:0,
                            errorCode:1
                        })                        
                    }
                })
                }else{
                    // 不存在
                    res.send({
                        state:2,
                        errorCode:0
                    })
                    return
                }
            })
            // 查询user_info表中是否包含该数据(password)
                // 包含：检查密码是否正确
                    // 正确
                    // 不正确
                // 不包含：返回小程序需要注册

        })

    app.post('/getUserAnswer',function(req,res){
        if(typeof req.body === 'string')
        req.body=JSON.parse(req.body)
        if(!req.body.hasOwnProperty('name')||!req.body.hasOwnProperty('openid')){
            res.send({
                state:0,
                errorCode:1,
                errorMes:'缺少参数'
            })
            return 
        }
        
        for(let item in req.body){
            if(typeof req.body[item] === 'string')
                if(req.body[item].trim().length<1){
                    res.send({
                        state:0,
                        errorCode:2,
                        errorMes:"数据值无效(上传数据为空|长度小于1)"
                    })
                    return
            }
        }           
        const {name,openid}=req.body
        // 查询用户的信息，并获取权限（）

        // state参数
        // 0：无权限
        // 1：拿到结果

        // errorCode参数
        // 0：无误
        // 1：无权限
        // 2：登录失败，请返回登录页面
        query(dbs,'mynameisczy_asia.user_info','user_privilege',{nickName:name,openid:openid}).then(v=>{
            if(v.length){
            // 查询到
                // 拿到权限
                const {user_privilege}=v[0]
                    // 有权限
                        // 根据权限去user_feedback里去寻找回复的参数
                        // author可以拿到全部的回复
                    if(user_privilege === 'author'){
                        query(dbs,'mynameisczy_asia.user_feedback',['nickName','avatarUrl','gender','content','feedback_time','feedback_to','openid']).then(value=>{
                            res.send({
                                state:1,
                                data:value,
                                errorCode:0
                            })
                        })                        
                        return
                    }else if(user_privilege === '小说提供猿'){ 
                        // 拿到表中的数据
                        query(dbs,'mynameisczy_asia.user_feedback',['nickName','avatarUrl','gender','content','feedback_time','feedback_to','openid'],{feedback_to:user_privilege}).then(value=>{
                            res.send({
                                state:1,
                                data:value,
                                errorCode:0
                            })
                        })
                        return
                    }else{
                        // 无权限      
                        res.send({
                            state:0,
                            errorCode:1
                        })
                        return
                    }
            }else{
            // 未查询到
                res.send({
                    state:0,
                    error:2
                })
            }
        })



    })
}